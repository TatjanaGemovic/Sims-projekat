using System;

namespace SIMS_Projekat.Model
{
   public class DoctorSpecialist : Doctor
   {
      public string Speciality { get; set; }

    }
}