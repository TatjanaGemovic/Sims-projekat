using System;

namespace SIMS_Projekat.Model
{
   public enum BloodType
   {
      oPositive,
      aPositive,
      bPositive,
      abPositive,
      oNegative,
      aNegative,
      bNegative,
      abNegative
   }
}