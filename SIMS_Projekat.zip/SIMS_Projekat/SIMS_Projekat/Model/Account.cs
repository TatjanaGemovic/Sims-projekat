using System;

namespace SIMS_Projekat.Model
{
    public class Account : Serialization.Serializable
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string Jmbg { get; set; }
        public string PhoneNumber { get; set; }
        public string Email { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string ID { get; set; }


        public virtual void fromCSV(string[] values)
        {
            throw new NotImplementedException();
        }

        public virtual string[] toCSV()
        {
            throw new NotImplementedException();
        }
    }
}