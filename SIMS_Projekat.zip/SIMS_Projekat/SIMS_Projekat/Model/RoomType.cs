using System;

namespace SIMS_Projekat.Model
{
   public enum RoomType
   {
      recoveryRoom,
      operatingRoom,
      examRoom,
      meetingRoom
   }
}